# API 交互流程图 - AI模型切换功能

## 📊 完整流程图

```
┌─────────────────────────────────────────────────────────────────────┐
│                         用户操作流程                                  │
└─────────────────────────────────────────────────────────────────────┘

1. 用户打开聊天界面
        │
        ├─→ 加载历史记录 (GET /api/ai/chat/history)
        │
2. 用户选择AI模型
        │
        ├─→ [默认] 🏫 Qwen (内网) → modelKey: "qwen-internal"
        │
        └─→ [新增] 🌐 Qwen (公网) → modelKey: "qwen-public"
        │
3. 用户输入消息并发送
        │
        └─→ 发送请求到后端


┌─────────────────────────────────────────────────────────────────────┐
│                      前端 → 后端 请求流程                             │
└─────────────────────────────────────────────────────────────────────┘

前端 (React)                      后端 (Java Spring Boot)
    │                                      │
    │  1. 获取JWT Token                     │
    │     localStorage.getItem('authToken') │
    │                                      │
    │  2. 构建请求                          │
    │     {                                │
    │       content: "用户消息",            │
    │       modelKey: "qwen-internal"      │
    │     }                                │
    │                                      │
    │  3. 发送HTTP请求                      │
    │  ─────────────────────────────────→  │
    │     POST /api/ai/chat                │  4. 接收请求
    │     Headers:                         │     └→ 验证JWT Token
    │       Authorization: Bearer <token>  │     └→ 解析请求体
    │       Content-Type: application/json │     └→ 获取 content & modelKey
    │     Body:                            │
    │       { content, modelKey }          │  5. 路由到AI服务
    │                                      │     └→ if (modelKey == "qwen-internal")
    │                                      │           调用内网AI
    │                                      │     └→ else if (modelKey == "qwen-public")
    │                                      │           调用公网AI
    │                                      │
    │                                      │  6. 获取AI响应
    │                                      │     └→ AI回复内容
    │                                      │
    │  8. 接收响应                          │  7. 构建响应
    │  ←─────────────────────────────────  │     {
    │     {                                │       success: true,
    │       success: true,                 │       content: "AI回复",
    │       content: "AI回复",              │       timestamp: "..."
    │       timestamp: "..."               │     }
    │     }                                │
    │                                      │
    │  9. 更新UI                            │
    │     └→ 显示AI消息                     │
    │     └→ 保存到聊天历史                 │
    │                                      │
```

---

## 🔍 详细请求示例

### 示例 1: 使用内网模型

#### 前端代码
```typescript
// AIChat.tsx
const handleSend = async () => {
  const userInput = "什么是Java多态？";
  const modelKey = "qwen-internal"; // 用户选择了内网模型
  
  const response = await sendChatMessage(userInput, modelKey);
};
```

#### HTTP请求
```http
POST http://localhost:8080/api/ai/chat HTTP/1.1
Host: localhost:8080
Content-Type: application/json
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIyMDIzMDAxIiwiaWF0IjoxNjk5MjAwMDAwfQ.xyz123

{
  "content": "什么是Java多态？",
  "modelKey": "qwen-internal"
}
```

#### 后端处理
```java
@PostMapping("/chat")
public ResponseEntity<ChatResponse> chat(
    @RequestHeader("Authorization") String token,
    @RequestBody ChatRequest request
) {
    // 1. 验证Token
    String jwt = token.replace("Bearer ", "");
    User user = jwtService.validateToken(jwt); // 验证通过
    
    // 2. 获取参数
    String content = request.getContent();      // "什么是Java多态？"
    String modelKey = request.getModelKey();    // "qwen-internal"
    
    // 3. 调用内网AI
    String aiResponse = internalAIService.chat(content);
    // AI回复: "Java多态是面向对象编程的三大特性之一..."
    
    // 4. 返回响应
    return ResponseEntity.ok(new ChatResponse(true, aiResponse));
}
```

#### HTTP响应
```http
HTTP/1.1 200 OK
Content-Type: application/json

{
  "success": true,
  "content": "Java多态是面向对象编程的三大特性之一，它允许不同类的对象对同一消息做出响应...",
  "timestamp": "2024-12-03T10:30:00Z"
}
```

---

### 示例 2: 切换到公网模型

#### 前端操作
```typescript
// 1. 用户点击切换按钮
<button onClick={() => setSelectedModel('qwen-public')}>
  🌐 Qwen (公网)
</button>

// 2. 状态更新
selectedModel = "qwen-public"

// 3. 发送消息
const response = await sendChatMessage("介绍一下Spring Boot", "qwen-public");
```

#### HTTP请求（注意 modelKey 变化）
```http
POST http://localhost:8080/api/ai/chat HTTP/1.1
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

{
  "content": "介绍一下Spring Boot",
  "modelKey": "qwen-public"  ← 这里变了！
}
```

#### 后端路由逻辑
```java
String modelKey = request.getModelKey(); // "qwen-public"

String aiResponse;
if ("qwen-internal".equals(modelKey)) {
    // 内网模型
    aiResponse = internalAIService.chat(content);
} else if ("qwen-public".equals(modelKey)) {
    // 公网模型 ← 执行这个分支
    aiResponse = publicAIService.chat(content);
} else {
    throw new IllegalArgumentException("不支持的模型: " + modelKey);
}
```

---

## 🔐 JWT认证流程

```
┌─────────────────────────────────────────────────────────────┐
│                      JWT认证流程                              │
└─────────────────────────────────────────────────────────────┘

1. 用户登录
   POST /api/auth/student/login
   {
     "studentId": "2023001",
     "password": "123456"
   }
        │
        ↓
   后端验证成功，生成JWT Token
        │
        ↓
   返回响应:
   {
     "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
     "user": { ... }
   }
        │
        ↓
2. 前端保存Token
   localStorage.setItem('authToken', response.token)
   
        │
        ↓
3. 后续所有请求携带Token
   fetch('/api/ai/chat', {
     headers: {
       'Authorization': `Bearer ${token}`
     }
   })
        │
        ↓
4. 后端验证Token
   JwtAuthenticationFilter
   └→ 解析Token
   └→ 验证签名
   └→ 检查过期时间
   └→ 提取用户信息
   └→ 设置SecurityContext
```

---

## 🎯 核心代码对应关系

### 前端核心文件
| 文件 | 功能 | 关键代码 |
|------|------|---------|
| `/api/chat.ts` | API封装 | `sendChatMessage(content, modelKey)` |
| `/components/AIChat.tsx` | UI组件 | `selectedModel` 状态管理 |
| `/utils/api-config.ts` | 配置 | `BASE_URL`, `getHeaders()` |

### 后端核心文件（需要实现）
| 文件 | 功能 | 关键代码 |
|------|------|---------|
| `AIChatController.java` | 控制器 | `@PostMapping("/chat")` |
| `ChatRequest.java` | DTO | `content`, `modelKey` 字段 |
| `JwtAuthenticationFilter.java` | 认证 | Token验证逻辑 |
| `AIService.java` | AI服务 | 调用内网/公网AI |

---

## 📝 请求/响应数据结构

### 请求体 (Request Body)
```typescript
interface ChatRequest {
  content: string;      // 必填：用户消息
  modelKey: ModelKey;   // 必填：'qwen-internal' | 'qwen-public'
}
```

### 响应体 (Response Body)
```typescript
interface ChatResponse {
  success: boolean;     // 必填：请求是否成功
  content?: string;     // 成功时：AI回复内容
  message?: string;     // 失败时：错误信息
  timestamp?: string;   // 可选：时间戳
}
```

---

## 🔄 状态流转图

```
┌──────────────────────────────────────────────────────────┐
│                    前端状态管理                            │
└──────────────────────────────────────────────────────────┘

初始状态
  │
  ├─ selectedModel: 'qwen-internal'  (默认)
  ├─ messages: []
  ├─ inputValue: ''
  └─ isAIThinking: false
  
        │
        ↓
        
用户选择模型
  │
  └→ setSelectedModel('qwen-public')
  
        │
        ↓
        
用户输入消息
  │
  └→ setInputValue('你好')
  
        │
        ↓
        
用户点击发送
  │
  ├→ setIsAIThinking(true)
  ├→ 添加用户消息到 messages
  ├→ 清空 inputValue
  └→ 调用 sendChatMessage(inputValue, selectedModel)
  
        │
        ↓
        
等待AI响应
  │
  └→ 显示"AI正在思考..."
  
        │
        ↓
        
收到响应
  │
  ├→ 添加AI消息到 messages
  └→ setIsAIThinking(false)
  
        │
        ↓
        
完成 (回到初始状态，等待下次输入)
```

---

## 🚨 错误处理流程

```
┌────────────────────────────────────────────────────────┐
│                   错误处理机制                           │
└────────────────────────────────────────────────────────┘

前端发送请求
    │
    ├─→ Token不存在?
    │   └→ ❌ 抛出错误: "未找到认证令牌，请先登录"
    │
    ├─→ 网络请求失败?
    │   └→ ❌ 显示: "网络连接失败，请检查网络"
    │
    ├─→ 后端返回4xx错误?
    │   ├→ 401: "未授权，请重新登录"
    │   ├→ 403: "无权限访问"
    │   └→ 400: "请求参数错误"
    │
    ├─→ 后端返回5xx错误?
    │   └→ ❌ "服务器内部错误，请稍后重试"
    │
    └─→ 响应格式错误?
        └→ ❌ "响应数据格式异常"

所有错误都会：
  1. 在控制台打印详细日志
  2. 在聊天界面显示友好提示
  3. 不影响其他功能继续使用
```

---

## 📊 性能优化建议

### 前端优化
1. **请求防抖**: 防止用户快速连续点击发送
2. **消息分页**: 历史消息过多时分页加载
3. **缓存策略**: 缓存常见问题的AI回复

### 后端优化
1. **Token缓存**: 避免每次都解析JWT
2. **AI响应缓存**: 相同问题返回缓存结果
3. **异步处理**: AI调用使用异步，避免阻塞

---

## 🔗 相关链接

- [完整实现指南](./AI-MODEL-SWITCH-GUIDE.md)
- [快速测试指南](./AI-QUICK-TEST.md)
- [后端API规范](./BACKEND-API-SPEC.md)

---

**文档版本**: 1.0  
**创建日期**: 2024-12-03  
**维护团队**: SUAT-GPT 开发组
