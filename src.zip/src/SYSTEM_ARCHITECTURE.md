# 🏗️ SUAT-GPT 系统架构文档

## 📐 整体架构

```
┌─────────────────────────────────────────────────────────┐
│                    前端应用 (React)                       │
├─────────────────────────────────────────────────────────┤
│                                                           │
│  ┌──────────────┐              ┌──────────────┐        │
│  │  学生端界面   │              │  教师后台界面  │        │
│  ├──────────────┤              ├──────────────┤        │
│  │ • AI 对话    │              │ • 数据概览    │        │
│  │ • 学习中心   │              │ • 课程管理    │        │
│  │ • 通知中心   │              │ • 学生管理    │        │
│  │ • 个人中心   │              │ • 作业管理    │        │
│  └──────────────┘              │ • 通知推送    │        │
│                                 └──────────────┘        │
│                                                           │
│                          ↕                               │
│                                                           │
│              REST API (fetch)                            │
│                                                           │
└─────────────────────────────────────────────────────────┘
                           ↕
┌─────────────────────────────────────────────────────────┐
│              Supabase Edge Functions (后端)              │
├─────────────────────────────────────────────────────────┤
│                                                           │
│  ┌──────────────────────────────────────────────┐      │
│  │        Hono Web Server (TypeScript)          │      │
│  ├──────────────────────────────────────────────┤      │
│  │                                               │      │
│  │  学生端 API              教师端 API           │      │
│  │  ├─ /courses            ├─ /admin/login     │      │
│  │  ├─ /homework           ├─ /admin/courses   │      │
│  │  ├─ /notifications      ├─ /admin/homework  │      │
│  │  ├─ /progress           ├─ /admin/students  │      │
│  │  ├─ /bookmarks          ├─ /admin/notifications │  │
│  │  └─ /notes              └─ /admin/analytics │      │
│  │                                               │      │
│  └──────────────────────────────────────────────┘      │
│                          ↕                               │
└─────────────────────────────────────────────────────────┘
                           ↕
┌─────────────────────────────────────────────────────────┐
│              Supabase KV Store (数据存储)                │
├─────────────────────────────────────────────────────────┤
│                                                           │
│  键值对存储结构：                                         │
│  • teacher:{id}              - 教师信息                  │
│  • student:{id}              - 学生信息                  │
│  • course:{id}               - 课程信息                  │
│  • homework:{courseId}:{id}  - 作业信息                  │
│  • submission:{userId}:{hwId}- 作业提交                  │
│  • notification:{userId}:{id}- 通知信息                  │
│  • progress:{userId}:{courseId} - 学习进度               │
│  • bookmarks:{userId}:{courseId} - 书签                 │
│  • notes:{userId}:{courseId} - 笔记                     │
│                                                           │
└─────────────────────────────────────────────────────────┘
                           ↕
┌─────────────────────────────────────────────────────────┐
│                  外部 AI 服务                             │
├─────────────────────────────────────────────────────────┤
│  • Deepseek-R1-671B   (10.22.18.101:9997)              │
│  • Qwen3-30B-A3B      (10.22.18.12:40011)              │
│  • Embedding Service  (10.22.18.12:40012)              │
└─────────────────────────────────────────────────────────┘
```

---

## 🔄 数据流转

### **1. 教师创建课程流程**

```
教师在后台点击"创建课程"
    ↓
填写课程信息（名称、教师、描述、章节数等）
    ↓
前端发送 POST 请求到 /admin/courses
    ↓
后端接收请求，生成课程ID
    ↓
保存到 KV Store: course:{courseId}
    ↓
返回成功响应
    ↓
前端刷新课程列表
    ↓
学生端调用 /courses 接口
    ↓
获取最新课程列表（包括新创建的课程）
    ↓
学生看到新课程
```

### **2. 教师推送通知流程**

```
教师在后台填写通知内容
    ↓
点击"发送给所有学生"
    ↓
前端发送 POST 请求到 /admin/notifications/broadcast
    ↓
后端查询所有学生列表
    ↓
为每个学生创建通知记录
    ↓
保存到 KV Store: notification:{studentId}:{notificationId}
    ↓
返回发送成功响应
    ↓
学生端定期轮询 /notifications/{userId}
    ↓
获取新通知
    ↓
学生通知中心显示新消息
```

### **3. 学生提交作业 → 教师批改流程**

```
学生端：
学生完成作业并提交
    ↓
前端发送 POST 请求到 /submissions/{userId}/{homeworkId}
    ↓
后端保存提交内容
    ↓
保存到 KV Store: submission:{userId}:{homeworkId}

教师端：
教师查看作业提交列表
    ↓
前端调用 GET /admin/submissions/{homeworkId}
    ↓
后端返回所有学生提交
    ↓
教师打分并提供反馈
    ↓
前端发送 PUT 请求到 /admin/submissions/{userId}/{homeworkId}
    ↓
后端更新提交记录（添加分数和反馈）
    ↓
自动创建通知给学生
    ↓
学生收到"作业已批改"通知
```

---

## 🛠️ 技术栈

### **前端技术栈**
- **框架**: React 18 + TypeScript
- **样式**: Tailwind CSS 4.0
- **图标**: Lucide React
- **状态管理**: React Hooks (useState, useEffect)
- **HTTP 客户端**: Fetch API
- **构建工具**: Vite

### **后端技术栈**
- **运行时**: Deno
- **语言**: TypeScript
- **Web框架**: Hono
- **数据存储**: Supabase KV Store
- **认证**: Simple Token (演示版)
- **部署**: Supabase Edge Functions

### **数据库**
- **类型**: Key-Value Store (KV Store)
- **提供商**: Supabase
- **查询方式**: 
  - `get(key)` - 获取单个值
  - `set(key, value)` - 设置值
  - `del(key)` - 删除值
  - `getByPrefix(prefix)` - 前缀查询
  - `mget(keys[])` - 批量获取
  - `mset(entries[])` - 批量设置

---

## 📡 API 接口设计

### **学生端 API**

| 方法 | 路径 | 功能 | 参数 |
|------|------|------|------|
| GET | `/courses` | 获取所有课程 | - |
| GET | `/courses/:id` | 获取课程详情 | courseId |
| GET | `/homework/:courseId` | 获取课程作业 | courseId |
| GET | `/notifications/:userId` | 获取用户通知 | userId |
| POST | `/submissions/:userId/:hwId` | 提交作业 | userId, hwId, content |
| GET | `/progress/:userId/:courseId` | 获取学习进度 | userId, courseId |
| POST | `/progress/:userId/:courseId` | 更新学习进度 | userId, courseId, progress |

### **教师端 API**

| 方法 | 路径 | 功能 | 参数 |
|------|------|------|------|
| POST | `/admin/login` | 教师登录 | username, password |
| POST | `/admin/courses` | 创建课程 | courseData |
| PUT | `/admin/courses/:id` | 更新课程 | courseId, updates |
| DELETE | `/admin/courses/:id` | 删除课程 | courseId |
| POST | `/admin/homework` | 创建作业 | homeworkData |
| PUT | `/admin/homework/:courseId/:id` | 更新作业 | courseId, hwId, updates |
| DELETE | `/admin/homework/:courseId/:id` | 删除作业 | courseId, hwId |
| GET | `/admin/submissions/:hwId` | 获取作业提交 | hwId |
| PUT | `/admin/submissions/:userId/:hwId` | 批改作业 | userId, hwId, score, feedback |
| GET | `/admin/students` | 获取学生列表 | - |
| GET | `/admin/students/:id` | 获取学生详情 | studentId |
| POST | `/admin/notifications` | 发送通知 | userId, title, message |
| POST | `/admin/notifications/broadcast` | 广播通知 | title, message, type |
| GET | `/admin/analytics` | 获取数据统计 | - |

---

## 🔐 安全架构

### **当前实现（演示版）**

```
┌─────────────┐
│   前端      │
├─────────────┤
│ localStorage│  ← 存储 teacher token
│ publicKey   │  ← Supabase public anonymous key
└─────────────┘
      ↓
┌─────────────┐
│   后端      │
├─────────────┤
│ 简单认证    │  ← 用户名/密码匹配
│ Token生成   │  ← teacher_{username}_{timestamp}
└─────────────┘
```

### **生产环境建议**

```
┌─────────────┐
│   前端      │
├─────────────┤
│ Supabase    │
│ Auth Client │  ← JWT tokens
│ Session管理 │  ← 安全的会话处理
└─────────────┘
      ↓
┌─────────────┐
│   后端      │
├─────────────┤
│ Supabase    │
│ Auth API    │  ← 验证JWT
│ Row Level   │  ← 行级安全策略
│ Security    │
└─────────────┘
      ↓
┌─────────────┐
│   数据库    │
├─────────────┤
│ RLS Policies│  ← 自动权限控制
│ 加密存储    │  ← 敏感数据加密
└─────────────┘
```

---

## 📊 数据模型

### **教师 (Teacher)**
```typescript
interface Teacher {
  username: string;      // 用户名
  password: string;      // 密码（生产环境需加密）
  name: string;          // 姓名
  email: string;         // 邮箱
  phone: string;         // 电话
  role: 'teacher';       // 角色
  createdAt: string;     // 创建时间
}
```

### **学生 (Student)**
```typescript
interface Student {
  id: string;            // 学生ID
  name: string;          // 姓名
  studentId: string;     // 学号
  email: string;         // 邮箱
  major: string;         // 专业
  class: string;         // 班级
  enrolledCourses: string[]; // 已选课程ID列表
}
```

### **课程 (Course)**
```typescript
interface Course {
  id: string;            // 课程ID
  name: string;          // 课程名称
  teacher: string;       // 教师姓名
  description: string;   // 课程描述
  totalChapters: number; // 总章节数
  completedChapters: number; // 已完成章节数
  progress: number;      // 完成进度百分比
  coverImage?: string;   // 封面图片URL
  chapters?: Chapter[];  // 章节列表
  createdAt: string;     // 创建时间
  updatedAt?: string;    // 更新时间
}
```

### **作业 (Homework)**
```typescript
interface Homework {
  id: string;            // 作业ID
  courseId: string;      // 所属课程ID
  title: string;         // 作业标题
  chapter: number;       // 章节号
  deadline: string;      // 截止日期
  totalScore: number;    // 总分
  status: 'active' | 'closed'; // 状态
  description?: string;  // 作业描述
  createdAt: string;     // 创建时间
}
```

### **作业提交 (Submission)**
```typescript
interface Submission {
  userId: string;        // 学生ID
  homeworkId: string;    // 作业ID
  content: string;       // 提交内容
  submittedAt: string;   // 提交时间
  status: 'submitted' | 'graded'; // 状态
  score?: number;        // 分数
  feedback?: string;     // 反馈
  gradedAt?: string;     // 批改时间
}
```

### **通知 (Notification)**
```typescript
interface Notification {
  id: string;            // 通知ID
  type: 'system' | 'course' | 'homework' | 'exam'; // 类型
  title: string;         // 标题
  message: string;       // 内容
  time: string;          // 时间（相对或绝对）
  read: boolean;         // 是否已读
  category: string;      // 分类
  createdAt: string;     // 创建时间
}
```

---

## 🚀 部署架构

### **前端部署**
- **平台**: Figma Make (内置托管)
- **CDN**: 自动配置
- **域名**: 自动生成

### **后端部署**
- **平台**: Supabase Edge Functions
- **区域**: 自动选择最近节点
- **扩展**: 自动伸缩

### **数据库部署**
- **平台**: Supabase
- **备份**: 自动备份
- **高可用**: 内置冗余

---

## 📈 扩展性设计

### **横向扩展**
- ✅ 支持多教师账号
- ✅ 支持无限学生
- ✅ 支持海量课程和作业

### **功能扩展**
- ✅ 插件化架构
- ✅ API 可复用
- ✅ 模块化设计

### **性能优化**
- ✅ 前端缓存策略
- ✅ API 响应缓存
- ✅ 数据懒加载

---

## 🔧 开发环境

### **本地开发**
```bash
# 启动前端开发服务器
npm run dev

# 运行后端本地测试
deno run --allow-net --allow-env server/index.tsx
```

### **调试工具**
- Chrome DevTools
- React DevTools
- Supabase Dashboard
- 内置 DebugPanel

---

## 📝 代码规范

### **前端代码**
- 使用 TypeScript 严格模式
- React Hooks 优先
- 组件化设计
- Tailwind CSS 工具类

### **后端代码**
- RESTful API 设计
- 统一错误处理
- 详细日志记录
- 类型安全

---

## ✅ 系统优势

1. **简单易用** - 无需复杂配置
2. **实时同步** - 数据秒级更新
3. **安全可靠** - 云端存储备份
4. **免费够用** - Supabase 免费套餐
5. **易于扩展** - 模块化架构

---

## 🎯 适用场景

- ✅ 教育机构
- ✅ 在线培训平台
- ✅ 企业内训系统
- ✅ 知识管理平台
- ✅ 学习管理系统（LMS）

---

**系统设计完整、架构清晰、扩展性强！** 🚀
