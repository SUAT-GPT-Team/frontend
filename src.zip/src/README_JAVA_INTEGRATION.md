# 🎓 SUAT-GPT Java课程作业版本

## ✅ 已完成的工作

我已经为您完成了以下工作，让前端可以完美对接Java后端：

---

## 📦 新增文件

### **1. 后端配置文件**
```
/config/backend.config.ts
```
- ✅ 支持切换Java/Supabase后端
- ✅ 配置Java后端地址
- ✅ 一键切换后端类型

### **2. 学生登录组件**
```
/components/StudentLogin.tsx
```
- ✅ 学生登录界面
- ✅ 用户名/密码认证
- ✅ 演示账号快捷登录
- ✅ JWT Token存储

### **3. Java后端API完整文档**
```
/docs/JAVA_BACKEND_API.md
```
- ✅ 数据库设计（9张表）
- ✅ 完整API接口规范
- ✅ Spring Boot实现示例
- ✅ JWT认证方案
- ✅ CORS配置
- ✅ 实体类示例

### **4. 快速开始指南**
```
/docs/QUICK_START.md
```
- ✅ 系统概述
- ✅ 后端配置步骤
- ✅ 学生端使用说明
- ✅ 教师端使用说明
- ✅ 常见问题解答

---

## 🔧 修改的文件

### **1. API调用层** (`/utils/api.ts`)
```typescript
// 修改点：
✅ 支持动态切换Java/Supabase后端
✅ 添加JWT Token认证
✅ 修改所有API路径以支持Java后端
✅ 添加学生登录API
✅ 所有请求自动携带学生ID（从localStorage读取）
```

### **2. 主应用** (`/App.tsx`)
```typescript
// 修改点：
✅ 添加学生登录流程
✅ 学生登录后显示个人信息
✅ 添加退出登录功能
✅ 学生未登录时强制跳转登录页
```

### **3. 教师后台** (`/components/AdminDashboard.tsx`)
```typescript
// 修改点：
✅ 学生管理 - 添加学生功能
✅ 学生管理 - 编辑学生信息
✅ 学生管理 - 删除学生
✅ 学生管理 - 重置密码
✅ 添加学生模态框
✅ 编辑学生模态框
```

---

## 🎯 当前系统架构

```
┌─────────────────────────────────────────┐
│         前端 (React + TypeScript)        │
│                                          │
│  • 学生登录 (/components/StudentLogin)  │
│  • 学生端界面                            │
│  • 教师后台 (含学生管理)                │
│                                          │
│  后端配置: /config/backend.config.ts    │
│  当前模式: BACKEND_TYPE = 'java'        │
└─────────────────────────────────────────┘
                   ↕ (REST API + JWT)
┌─────────────────────────────────────────┐
│      Java 后端 (需要您开发)              │
│                                          │
│  技术栈:                                 │
│  • Java 17+                             │
│  • Spring Boot 3.x                      │
│  • Spring Data JPA                      │
│  • Spring Security + JWT                │
│  • MySQL 8.0+                           │
│                                          │
│  API文档: /docs/JAVA_BACKEND_API.md    │
└─────────────────────────────────────────┘
                   ↕
┌─────────────────────────────────────────┐
│          MySQL 数据库                    │
│                                          │
│  数据表:                                 │
│  • students (学生表)                    │
│  • teachers (教师表)                    │
│  • courses (课程表)                     │
│  • homework (作业表)                    │
│  • submissions (作业提交表)             │
│  • notifications (通知表)               │
│  • progress (学习进度表)                │
│  • bookmarks (书签表)                   │
│  • notes (笔记表)                       │
│                                          │
│  建表SQL: 见 API文档                     │
└─────────────────────────────────────────┘
```

---

## 🚀 下一步：您需要做的

### **第1步：切换到Java后端模式**

打开 `/config/backend.config.ts`，确认配置：

```typescript
export const BACKEND_TYPE: BackendType = 'java';  // ✅ 已设置

export const JAVA_BACKEND_CONFIG = {
  baseUrl: 'http://localhost:8080/api',  // 修改为您的后端地址
  timeout: 10000,
  enableAuth: true,
};
```

---

### **第2步：创建Java后端项目**

#### **创建Spring Boot项目**
```bash
# 使用 Spring Initializr 或 IDE创建项目
# 选择依赖:
- Spring Web
- Spring Data JPA
- Spring Security
- MySQL Driver
- Lombok
```

#### **项目结构**
```
suat-backend/
├── src/main/java/com/suat/
│   ├── SuatApplication.java
│   ├── config/
│   │   ├── CorsConfig.java
│   │   ├── SecurityConfig.java
│   │   └── JwtConfig.java
│   ├── controller/
│   │   ├── StudentAuthController.java
│   │   ├── TeacherAuthController.java
│   │   ├── CourseController.java
│   │   ├── HomeworkController.java
│   │   ├── NotificationController.java
│   │   └── AdminController.java
│   ├── service/
│   ├── repository/
│   └── entity/
└── src/main/resources/
    └── application.properties
```

---

### **第3步：创建数据库**

```sql
CREATE DATABASE suat_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE suat_db;

-- 执行建表SQL（参考 /docs/JAVA_BACKEND_API.md）
```

---

### **第4步：实现API接口**

参考 `/docs/JAVA_BACKEND_API.md`，实现以下接口：

#### **必须实现的接口（按优先级）**

**优先级1 - 认证相关：**
```
✅ POST /api/auth/student/login     - 学生登录（必须！）
✅ POST /api/auth/teacher/login     - 教师登录（必须！）
```

**优先级2 - 学生端核心功能：**
```
✅ GET  /api/courses                - 获取课程列表
✅ GET  /api/courses/{id}           - 获取课程详情
✅ GET  /api/homework/{courseId}    - 获取作业列表
✅ POST /api/submissions/{hwId}     - 提交作业
✅ GET  /api/notifications          - 获取通知
```

**优先级3 - 教师端学生管理：**
```
✅ GET    /api/admin/students           - 获取学生列表
✅ POST   /api/admin/students           - 添加学生（重要！）
✅ PUT    /api/admin/students/{id}      - 更新学生信息
✅ DELETE /api/admin/students/{id}      - 删除学生
✅ POST   /api/admin/students/{id}/reset-password - 重置密码
```

**优先级4 - 教师端课程管理：**
```
✅ POST   /api/admin/courses            - 创建课程
✅ PUT    /api/admin/courses/{id}       - 更新课程
✅ DELETE /api/admin/courses/{id}       - 删除课程
```

**优先级5 - 教师端通知推送：**
```
✅ POST /api/admin/notifications/broadcast - 广播通知
```

---

### **第5步：配置CORS（重要！）**

```java
@Configuration
public class CorsConfig {
    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/api/**")
                    .allowedOrigins("*")  // 允许所有来源
                    .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                    .allowedHeaders("*")
                    .exposedHeaders("Authorization")
                    .allowCredentials(false)
                    .maxAge(3600);
            }
        };
    }
}
```

---

### **第6步：测试连接**

#### **测试后端健康检查**
```bash
curl http://localhost:8080/api/health
```

#### **测试学生登录**
```bash
curl -X POST http://localhost:8080/api/auth/student/login \
  -H "Content-Type: application/json" \
  -d '{"username":"zhangsan","password":"123456"}'
```

预期返回：
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "student": {
    "id": "student-001",
    "username": "zhangsan",
    "name": "张三",
    "studentId": "2021001",
    "email": "zhangsan@suat.edu.cn"
  }
}
```

---

### **第7步：启动完整系统**

```bash
# 1. 启动数据库
mysql -u root -p

# 2. 启动Java后端
mvn spring-boot:run

# 3. 启动前端（Figma Make中自动运行）
# 前端会自动连接到 http://localhost:8080/api
```

---

## 📱 功能测试流程

### **测试1：学生登录**
1. 打开应用
2. 看到学生登录页面
3. 点击"使用演示账号登录"
4. 自动填充 zhangsan/123456
5. 登录成功，进入学生端

### **测试2：教师添加学生**
1. 点击右上角"教师入口"
2. 登录教师账号（admin@suat.edu.cn / password123）
3. 点击"学生管理"标签
4. 点击"添加学生"按钮
5. 填写新学生信息：
   ```
   用户名: wangwu
   密码: 123456
   姓名: 王五
   学号: 2021003
   专业: 软件工程
   班级: 21软工1班
   ```
6. 点击"添加"
7. 查看学生列表，确认新增成功
8. 退出教师后台
9. 使用新学生账号登录（wangwu/123456）
10. 验证登录成功

### **测试3：教师创建课程**
1. 教师登录后台
2. 点击"课程管理"
3. 点击"创建课程"
4. 填写课程信息并创建
5. 学生端刷新，确认看到新课程

### **测试4：教师推送通知**
1. 教师点击"通知推送"
2. 填写通知内容并发送
3. 学生端查看通知中心
4. 确认收到通知

---

## 🐛 调试技巧

### **前端调试**
```javascript
// 打开浏览器控制台 (F12)

// 查看当前后端配置
console.log('当前后端类型:', BACKEND_TYPE);
console.log('后端地址:', API_BASE);

// 查看当前登录状态
console.log('学生信息:', localStorage.getItem('student'));
console.log('Token:', localStorage.getItem('studentToken'));
```

### **后端调试**
```java
// 在Controller中添加日志
@PostMapping("/auth/student/login")
public ResponseEntity<?> login(@RequestBody LoginRequest request) {
    log.info("学生登录请求: {}", request.getUsername());
    // ...
    return ResponseEntity.ok(response);
}
```

### **网络请求调试**
```
F12 → Network 标签
筛选: Fetch/XHR
查看请求URL、请求头、响应数据
```

---

## 📚 重要文档

| 文档 | 路径 | 用途 |
|------|------|------|
| **Java API完整文档** | `/docs/JAVA_BACKEND_API.md` | 所有API接口规范、数据库设计 |
| **快速开始指南** | `/docs/QUICK_START.md` | 配置和使用说明 |
| **系统架构文档** | `/SYSTEM_ARCHITECTURE.md` | 系统整体架构 |
| **后端配置文件** | `/config/backend.config.ts` | 切换后端类型 |

---

## ✅ 检查清单

在开始开发前，请确认：

- [ ] 已阅读 `/docs/JAVA_BACKEND_API.md`
- [ ] 已创建MySQL数据库 `suat_db`
- [ ] 已创建Spring Boot项目
- [ ] 已配置 `/config/backend.config.ts`
- [ ] 已理解JWT认证流程
- [ ] 已理解API响应格式

开发完成后，请确认：

- [ ] 所有优先级1-5的API都已实现
- [ ] 学生可以正常登录
- [ ] 教师可以添加学生
- [ ] 教师可以创建课程
- [ ] 教师可以推送通知
- [ ] CORS配置正确
- [ ] JWT Token正常工作
- [ ] 前后端数据正常同步

---

## 💡 温馨提示

1. **密码加密**: 请使用BCrypt加密存储密码
2. **JWT Secret**: 请在 application.properties 中配置JWT密钥
3. **错误处理**: 所有API都应该返回统一的错误格式
4. **日志记录**: 添加详细的日志便于调试
5. **数据验证**: 在Controller层做好参数验证

---

## 🎉 总结

**前端已完成：**
- ✅ 学生登录系统
- ✅ 教师后台学生管理
- ✅ Java后端对接配置
- ✅ 完整的API调用层

**您需要开发：**
- ⏳ Java后端（Spring Boot）
- ⏳ 数据库表和初始数据
- ⏳ API接口实现
- ⏳ JWT认证系统

**预计开发时间：**
- 熟悉Spring Boot: 2-3天
- 实现核心API: 3-5天
- 测试和调试: 1-2天
- **总计: 约1周**

---

**祝您开发顺利！如有问题，请参考相关文档或查看控制台错误信息。** 🚀

---

**重要提示：** 
当前前端配置已切换到Java后端模式。如果您的Java后端还未完成，系统将无法正常工作。您可以：
1. 开发Java后端（推荐，符合课程要求）
2. 临时切换回Supabase后端测试前端功能（修改 backend.config.ts 中的 BACKEND_TYPE 为 'supabase'）
